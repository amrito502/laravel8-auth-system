


<script src="{{ asset('admin/vendors/core/core.js') }}"></script>
<script src="{{ asset('admin/vendors/flatpickr/flatpickr.min.js') }}"></script>
<script src="{{ asset('admin/vendors/apexcharts/apexcharts.min.js') }}"></script>

<script src="{{ asset('admin/vendors/feather-icons/feather.min.js') }}"></script>
<script src="{{ asset('admin/js/template.js') }}"></script>

<script src="{{ asset('admin/js/dashboard-light.js') }}"></script>

</body>

</html>
