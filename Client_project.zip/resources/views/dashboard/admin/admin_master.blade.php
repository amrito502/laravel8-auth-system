@include('dashboard.admin.components.header')

@include('dashboard.admin.components.main_nav_body_content')

@include('dashboard.admin.components.footer')


{{-- ================== --}}
