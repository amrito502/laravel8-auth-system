@extends('dashboard.admin.admin_master')
@section('admin_content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="shadow p-4">
                <h1 class="mb-3"  style="text-transform: capitalize;">{{ Auth::guard('admin')->user()->name }}</h1>
                <hr>
                <h3 class="">Welcome to Dashboard</h3>
            </div>
        </div>
    </div>
</div>
@endsection
