@extends('app.app_master')
@section('app_content')
@include('app.components.banner.other_page_banner')
@include('app.components.project.project')
@endsection
