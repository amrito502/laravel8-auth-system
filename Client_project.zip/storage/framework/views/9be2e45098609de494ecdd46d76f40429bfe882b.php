<?php $__env->startSection('admin_content'); ?>
    <p class="alert-success">
        <?php

        use Illuminate\Support\Facades\Session;

        $message = Session::get('success');
        if ($message) {
            echo $message;
            Session::put('success', null);
        }
        ?>
    </p>

    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h6 class="card-title dm-sans pt-3" style="font-size: 20px; font-weight: bold;">All Messages</h6>
                </div>
                <div class="card-body">

                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th style="5%" scope="col">ID</th>
                                    <th style="10%" scope="col">Name</th>
                                    <th style="10%" scope="col">Email</th>
                                    <th style="10%" scope="col">Subject</th>
                                    <th style="10%" scope="col">Messages</th>
                                    <th style="30%" scope="col">Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($message->name); ?></td>
                                        <td><?php echo e($message->email); ?></td>
                                        <td><?php echo e($message->subject); ?></td>
                                        <td><?php echo e($message->message); ?></td>
                                        <td>
                                            <a  onclick="return confirm('Are you sure to delete');" href="<?php echo e(route('admin.delete.message', $message->id)); ?>" class="btn btn-sm btn-danger">Delete Message</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="text-center text-danger">Message is not Available!</p>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Client_project\resources\views/dashboard/admin/pages/message.blade.php ENDPATH**/ ?>