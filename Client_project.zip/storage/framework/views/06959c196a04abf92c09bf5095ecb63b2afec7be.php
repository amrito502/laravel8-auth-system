<?php $__env->startSection('app_content'); ?>
<?php echo $__env->make('app.components.banner.other_page_banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="section-title position-relative text-center mb-5 pb-2 wow fadeInUp" data-wow-delay="0.1s">
    <h6 class="position-relative d-inline text-primary ps-4">
        My Blogs
    </h6>
    <h2 class="mt-2">Recently Posted Blogs</h2>
</div>



<?php echo $__env->make('app.components.blogs.blog_details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('app.app_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Client_project\resources\views/app/pages/blog_details.blade.php ENDPATH**/ ?>