


<script src="<?php echo e(asset('admin/vendors/core/core.js')); ?>"></script>
<script src="<?php echo e(asset('admin/vendors/flatpickr/flatpickr.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/vendors/apexcharts/apexcharts.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/vendors/feather-icons/feather.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/template.js')); ?>"></script>

<script src="<?php echo e(asset('admin/js/dashboard-light.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\Client_project\resources\views/dashboard/admin/components/footer.blade.php ENDPATH**/ ?>