<?php $__env->startSection('admin_content'); ?>
    <p class="alert-success">
        <?php

        use Illuminate\Support\Facades\Session;

        $message = Session::get('success');
        if ($message) {
            echo $message;
            Session::put('success', null);
        }
        ?>
    </p>

    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h6 class="card-title dm-sans pt-3" style="font-size: 20px; font-weight: bold;">All Team Members</h6>
                    <div class="Btn">
                        <a href="<?php echo e(route('admin.add.team')); ?>" class="btn btn-success dm-sans mt-2" style="font-size: 16px; font-weight: bold; padding-top: 10px">Add Team</a>
                    </div>
                </div>
                <div class="card-body">

                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th style="5%" scope="col">ID</th>
                                    <th style="10%" scope="col">Team Member Name</th>
                                    <th style="10%" scope="col">Profession</th>
                                    <th style="10%" scope="col">Team Member Photo</th>
                                    <th style="30%" scope="col">Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td><?php echo e($team->id); ?></td>
                                        <td><?php echo e($team->name); ?></td>
                                        <td><?php echo e($team->profession); ?></td>
                                        <td><img src="<?php echo e(asset('images/teams/' . $team->image)); ?>" style="width: 100px"
                                                alt="img" /></td>
                                        <td class="center">
                                            <a class="btn btn-sm btn-info" href="<?php echo e(route('admin.edit.team', $team->id)); ?>">
                                                <i class="halflings-icon white edit"></i> Edit
                                            </a>
                                            <a class="btn btn-sm btn-danger"
                                                onclick="return confirm('Are you sure to delete');" href="<?php echo e(route('admin.delete.team',$team->id)); ?>">
                                                <i class="halflings-icon white trash"></i> Delete
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Client_project\resources\views/dashboard/admin/pages/teams/teams.blade.php ENDPATH**/ ?>