
            <!-- ============Full Screen Search Start============ -->
            <div class="modal fade" id="searchModal" tabindex="-1">
                <div class="modal-dialog modal-fullscreen">
                    <div class="modal-content" style="background: rgba(29, 29, 39, 0.7)">
                        <div class="modal-header border-0">
                            <button
                                type="button"
                                class="btn bg-white btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                            ></button>
                        </div>
                        <div class="modal-body d-flex align-items-center justify-content-center">
                            <div class="input-group" style="max-width: 600px">
                                <input type="text" class="form-control bg-transparent border-light p-3" placeholder="Type search keyword">
                                <button class="btn btn-light px-4">
                                    <i class="bi bi-search"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============Full Screen Search End============ -->
<?php /**PATH C:\xampp\htdocs\Client_project\resources\views/app/components/search.blade.php ENDPATH**/ ?>