<?php $__env->startSection('admin_content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="shadow p-4">
                <h1 class="mb-3"  style="text-transform: capitalize;"><?php echo e(Auth::guard('admin')->user()->name); ?></h1>
                <hr>
                <h3 class="">Welcome to Dashboard</h3>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Client_project\resources\views/dashboard/admin/home.blade.php ENDPATH**/ ?>