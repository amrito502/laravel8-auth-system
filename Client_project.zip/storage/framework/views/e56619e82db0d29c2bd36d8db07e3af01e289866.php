<?php $__env->startSection('admin_content'); ?>
    <div class="col-lg-6 grid-margin stretch-card">
        <div class="card">

            <div class="card-body">
                <h4 class="card-title mb-4 dm-sans" style="font-size: 22px; font-weight: 700; color:#5660d9;">Edit LOGO FORM</h4>
                <form action="<?php echo e(route('admin.update.logo', $logo->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row mb-3">
                        <div class="col-lg-3">
                            <label for="logo_text" class="col-form-label">Logo Text</label>
                        </div>
                        <div class="col-lg-8">
                            <input class="form-control" name="logo_text" value="<?php echo e($logo->logo_text); ?>" id="logo_text" type="text">
                            <span class="text-danger"><?php $__errorArgs = ['logo_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-lg-3">
                            <label for="logo" class="col-form-label">Choose Photo</label>
                        </div>
                        <div class="col-lg-8">
                            <img src="<?php echo e(asset('images/logo/'.$logo->image)); ?>" width="100px" alt="alttt">
                            <input class="form-control" name="image" id="logo" type="file">
                        </div>
                    </div>
                    <div class="btn_submit d-flex justify-content-end mx-5 mt-3">
                        <input class="btn btn-primary mx-2" type="submit" value="Update Logo">
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Client_project\resources\views/dashboard/admin/pages/logo/edit_logo.blade.php ENDPATH**/ ?>