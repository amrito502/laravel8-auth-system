<?php $__env->startSection('admin_content'); ?>
    <p class="alert-success">
        <?php

        use Illuminate\Support\Facades\Session;

        $message = Session::get('message');
        if ($message) {
            echo $message;
            Session::put('message', null);
        }
        ?>
    </p>



    <div class="row">
        <div class="col-md-8 grid-margin stretch-card">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h6 class="card-title">All Logo</h6>
                    <a href="<?php echo e(route('admin.add.logo')); ?>" class="btn btn-success">Add Logo</a>
                </div>
                <div class="card-body">

                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Text Logo</th>
                                    <th>Image</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $logos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <th><?php echo e($logo->id); ?></th>
                                    <th><?php echo e($logo->logo_text); ?></th>
                                    <th><img src="<?php echo e(asset('images/logo/'.$logo->image)); ?>" width="100px" alt="alttt"></th>
                                    <td>
                                        <a href="<?php echo e(route('admin.edit.logo', $logo->id)); ?>" class="btn btn-info">Edit</a>
                                        <a  onclick="return confirm('Are you sure to delete');" href="<?php echo e(route('admin.delete.logo', $logo->id)); ?>" class="btn btn-danger">Delete</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="text-danger text-center">Data is not available Right Now!</p>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Client_project\resources\views/dashboard/admin/pages/logo/logo.blade.php ENDPATH**/ ?>