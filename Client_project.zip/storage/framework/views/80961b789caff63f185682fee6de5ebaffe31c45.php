  <!-- ==========Navbar & Hero Start========== -->
  <div class="container-xxl position-relative p-0">
      <nav class="navbar navbar-expand-lg navbar-light px-4 px-lg-5 py-3 py-lg-0">
          <a href="" class="navbar-brand p-0">
              <h1 class="m-0">
                  Zaman IT
                  <span class="fs-5 text-danger">Consulting</span>
              </h1>
              <!-- <img src="img/logo.png" alt="Logo"> -->
          </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
              <span class="fa fa-bars"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarCollapse">
              <div class="navbar-nav ms-auto py-0">
                  <a href="<?php echo e(route('app.home')); ?>" class="nav-item nav-link active">Home</a>
                  <a href="<?php echo e(route('app.about')); ?>" class="nav-item nav-link">About</a>
                  <a href="<?php echo e(route('app.services')); ?>" class="nav-item nav-link">Service</a>
                  <a href="<?php echo e(route('app.project')); ?>" class="nav-item nav-link">Project</a>
                  <a href="<?php echo e(route('app.teams')); ?>" class="nav-item nav-link">Our Team</a>
                  <a href="<?php echo e(route('app.blogs')); ?>" class="nav-item nav-link">Blogs</a>
                  <a href="<?php echo e(route('app.contact')); ?>" class="nav-item nav-link">Contact</a>
              </div>
              <butaton type="button" class="btn text-secondary ms-3" data-bs-toggle="modal" data-bs-target="#searchModal">
                  <i class="fa fa-search">
                  </i>
              </butaton>
              <a href="https://www.upwork.com/freelancers/~015157301e2ac694dc?fbclid=IwAR3vYox7L-R_0VzgpyxjfJ2G23PWlBpZTtpKMzKTwS1bxNB7vv-LV97h6O4"
                  class="btn btn-secondary text-light rounded-pill py-2 px-4 ms-3" target="_blank">Hire Me
              </a>
          </div>
      </nav>
      <?php echo $__env->make('app.components.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
  <!-- ==========Navbar & Hero End========== -->
<?php /**PATH C:\xampp\htdocs\Client_project\resources\views/app/components/navbar.blade.php ENDPATH**/ ?>