<!-- ============Portfolio Start============ -->
<div class="container-xxl py-5">
    <div class="container px-lg-5">
        <div class="section-title position-relative text-center mb-5 pb-2 wow fadeInUp" data-wow-delay="0.1s">
            <h6 class="position-relative d-inline text-primary ps-4">
                Our Projects
            </h6>
            <h2 class="mt-2">Recently Launched Projects</h2>
        </div>
        <div class="row mt-n2 wow fadeInUp" data-wow-delay="0.1s">
            <div class="col-12 text-center">
                <ul class="list-inline mb-5" id="portfolio-flters">
                    <li class="btn px-3 pe-4 active" data-filter="*">All</li>
                    <li class="btn px-3 pe-4" data-filter=".first">SEO</li>
                    <li class="btn px-3 pe-4" data-filter=".second">
                        Web Development
                    </li>
                </ul>
            </div>
        </div>
        <div class="row g-4 portfolio-container">
            <div class="col-lg-4 col-md-6 portfolio-item first wow zoomIn" data-wow-delay="0.1s">
                <div class="position-relative rounded overflow-hidden">
                    <img class="img-fluid w-100 project_cus_img" src="assets/img/go.jpeg" alt="">
                    <div class="portfolio-overlay">
                        <a class="btn btn-light project_display_img" href="assets/img/go.jpeg"
                            data-lightbox="portfolio">
                            <i class="fa fa-plus fa-2x text-primary">
                            </i>
                        </a>
                        <div class="mt-auto">
                            <small class="text-white">
                                <i class="fa fa-folder me-2"></i>SEO
                            </small>
                            <a class="h5 d-block text-white mt-1 mb-0" href="">Project in seo
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 portfolio-item second wow zoomIn" data-wow-delay="0.3s">
                <div class="position-relative rounded overflow-hidden">
                    <img class="img-fluid w-100 project_cus_img" src="assets/img/3.png" alt="">
                    <div class="portfolio-overlay">
                        <a class="btn btn-light project_display_img" href="assets/img/3.png" data-lightbox="portfolio">
                            <i class="fa fa-plus fa-2x text-primary">
                            </i>
                        </a>
                        <div class="mt-auto">
                            <small class="text-white">
                                <i class="fa fa-folder me-2"></i>Web Development
                            </small>
                            <a class="h5 d-block text-white mt-1 mb-0" href="">The web development life cycle is
                                a method that outlines the stages involved in building websites and web applications.
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 portfolio-item first wow zoomIn" data-wow-delay="0.6s">
                <div class="position-relative rounded overflow-hidden">
                    <img class="img-fluid w-100 project_cus_img" src="assets/img/4.png" alt="">
                    <div class="portfolio-overlay">
                        <a class="btn btn-light project_display_img" href="assets/img/4.png" data-lightbox="portfolio">
                            <i class="fa fa-plus fa-2x text-primary">
                            </i>
                        </a>
                        <div class="mt-auto">
                            <small class="text-white">
                                <i class="fa fa-folder me-2"></i>SEO project
                            </small>
                            <a class="h5 d-block text-white mt-1 mb-0" href="">improving your website to increase
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 portfolio-item first wow zoomIn" data-wow-delay="0.1s">
                <div class="position-relative rounded overflow-hidden">
                    <img class="img-fluid w-100 project_cus_img" src="assets/img/driftervans.png" alt="">
                    <div class="portfolio-overlay">
                        <a class="btn btn-light project_display_img" href="assets/img/driftervans.png"
                            data-lightbox="portfolio">
                            <i class="fa fa-plus fa-2x text-primary">
                            </i>
                        </a>
                        <div class="mt-auto">
                            <small class="text-white">
                                <i class="fa fa-folder me-2"></i>SEO
                            </small>
                            <a class="h5 d-block text-white mt-1 mb-0" href="">keywords in the page's content
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 portfolio-item first wow zoomIn" data-wow-delay="0.3s">
                <div class="position-relative rounded overflow-hidden">
                    <img class="img-fluid w-100 project_cus_img" src="assets/img/projectholidays.png" alt="">
                    <div class="portfolio-overlay">
                        <a class="btn btn-light project_display_img" href="assets/img/projectholidays.png"
                            data-lightbox="portfolio">
                            <i class="fa fa-plus fa-2x text-primary">
                            </i>
                        </a>
                        <div class="mt-auto">
                            <small class="text-white">
                                <i class="fa fa-folder me-2"></i>Products you sell
                            </small>
                            <a class="h5 d-block text-white mt-1 mb-0" href="">search engine optimization
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 portfolio-item second wow zoomIn" data-wow-delay="0.6s">
                <div class="position-relative rounded overflow-hidden">
                    <img class="img-fluid w-100 project_cus_img" src="assets/img/lishfood.png" alt="">
                    <div class="portfolio-overlay">
                        <a class="btn btn-light project_display_img" href="assets/img/lishfood.png"
                            data-lightbox="portfolio">
                            <i class="fa fa-plus fa-2x text-primary">
                            </i>
                        </a>
                        <div class="mt-auto">
                            <small class="text-white">
                                <i class="fa fa-folder me-2"></i>App Development
                            </small>
                            <a class="h5 d-block text-white mt-1 mb-0" href="">Developing an app has become
                                easier with the help of various software programs
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ============Portfolio End============ -->
<?php /**PATH C:\xampp\htdocs\Client_project\resources\views/app/components/project.blade.php ENDPATH**/ ?>