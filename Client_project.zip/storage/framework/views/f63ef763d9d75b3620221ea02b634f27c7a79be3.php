<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap.min.css')); ?>">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-6 mt-5">
            <h4>Admin Dashboard</h4> <hr>
            <table class="table table-bordered">
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
                <tr>
                    <td><?php echo e(Auth::guard('admin')->user()->name); ?></td>
                    <td><?php echo e(Auth::guard('admin')->user()->email); ?></td>
                    <td>
                        <a class="btn btn-sm btn-info" href="<?php echo e(route('admin.logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
                        <form action="<?php echo e(route('admin.logout')); ?>" method="post" class="d-none" id="logout-form"><?php echo csrf_field(); ?></form>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\projects\auth_system\resources\views/dashboard/admin/home.blade.php ENDPATH**/ ?>