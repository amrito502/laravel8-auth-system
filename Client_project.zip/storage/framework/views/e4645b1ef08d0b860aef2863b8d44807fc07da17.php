<section class="service_details">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <div class="service">
                    <img src="<?php echo e(asset('images/services/' . $service->image)); ?>" style="width: 100%!important;" alt="img" />
                    <div class="services_content">
                        <p class="service_date"><i class="fa fa-calendar"></i> <a href="#"><span class=""><?php echo e($service->created_at); ?></span></a></p>
                        <h3 class="service_d_name"><?php echo e($service->service_name); ?></h3>
                        <h6 class="service_d_title"><?php echo e($service->service_title); ?></h6>
                        <p class="service_d_desc"><?php echo e($service->description); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="ad">
                    <p>Show Ad</p>
                </div>
            </div>
        </div>
    </div>
</section>



<?php /**PATH C:\xampp\htdocs\Client_project\resources\views/app/components/services/service_details.blade.php ENDPATH**/ ?>