<!-- ============Service Start============ -->
<div class="container-xxl py-5">
    <div class="container px-lg-5">
        <div class="section-title position-relative text-center mb-5 pb-2 wow fadeInUp" data-wow-delay="0.1s">
            <h6 class="position-relative d-inline text-primary ps-4">
                Our Services
            </h6>
            <h2 class="mt-2">What Solutions We Provide</h2>
        </div>
        <div class="row g-4">
            <div class="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.1s">
                <div class="service-item d-flex flex-column justify-content-center text-center rounded">
                    <div class="service-icon flex-shrink-0">
                        <img class="service_icon" src="assets/img/search-engine-optimization.png" alt="">
                    </div>
                    <h5 class="mb-3">SEO Optimization</h5>
                    <p>
                        SEO optimization is the process of optimizing a website or web
                        page to increase its visibility in organic search engine
                        results.
                    </p>
                    <a class="btn px-3 mt-auto mx-auto" href="">Read More</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.3s">
                <div class="service-item d-flex flex-column justify-content-center text-center rounded">
                    <div class="service-icon flex-shrink-0">
                        <img class="service_icon" src="assets/img/app-development.png" alt="">
                    </div>
                    <h5 class="mb-3">Web Development</h5>
                    <p>
                        We provide web development services for a wide variety of
                        needs. Our services range from creating custom websites.
                    </p>
                    <a class="btn px-3 mt-auto mx-auto" href="">Read More</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.6s">
                <div class="service-item d-flex flex-column justify-content-center text-center rounded">
                    <div class="service-icon flex-shrink-0">
                        <img class="service_icon" src="assets/img/bullhorn.png" alt="">
                    </div>
                    <h5 class="mb-3">Social Media Marketing</h5>
                    <p>
                        Organic strategies will include leveraging existing
                        relationships, engaging with relevant influencers.
                    </p>
                    <a class="btn px-3 mt-auto mx-auto" href="">Read More</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.1s">
                <div class="service-item d-flex flex-column justify-content-center text-center rounded">
                    <div class="service-icon flex-shrink-0">
                        <img class="service_icon" src="assets/img/mobile.png" alt="">
                    </div>
                    <h5 class="mb-3">Web Design</h5>
                    <p>
                        Web design is the process of creating and maintaining
                        websites. It involves a variety of aspects, including website
                        layout, content production.
                    </p>
                    <a class="btn px-3 mt-auto mx-auto" href="">Read More</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.3s">
                <div class="service-item d-flex flex-column justify-content-center text-center rounded">
                    <div class="service-icon flex-shrink-0">
                        <img class="service_icon" src="assets/img/link.png" alt="">
                    </div>
                    <h5 class="mb-3">Linkbuilding</h5>
                    <p>
                        Linkbuilding is an SEO technique that involves creating links
                        from other websites to your own to improve organic search
                        engine rankings.
                    </p>
                    <a class="btn px-3 mt-auto mx-auto" href="">Read More</a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow zoomIn" data-wow-delay="0.6s">
                <div class="service-item d-flex flex-column justify-content-center text-center rounded">
                    <div class="service-icon flex-shrink-0">
                        <img class="service_icon" src="assets/img/mobile-development.png" alt="">
                    </div>
                    <h5 class="mb-3">App Development</h5>
                    <p>
                        App development is the process of creating software
                        applications for mobile devices such as smartphones and
                        tablets.
                    </p>
                    <a class="btn px-3 mt-auto mx-auto" href="">Read More</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ============Service End============ -->
<?php /**PATH C:\xampp\htdocs\Client_project\resources\views/app/components/services.blade.php ENDPATH**/ ?>