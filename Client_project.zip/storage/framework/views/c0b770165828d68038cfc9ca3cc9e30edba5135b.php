<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>User Login</title>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap.min.css')); ?>">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4 p-4" style="margin-top: 200px; border: 1px solid green">
                <h4 class="text-center">User Login</h4><hr>
                <form action="<?php echo e(route('user.check')); ?>" method="post">
                    
                    <?php if(Session::get('fail')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(Session::get('fail')); ?>

                    </div>
                    <?php endif; ?>

                    <?php echo csrf_field(); ?>
                    <div class="form-group my-2">
                        <label for="email">Email</label>
                        <input type="text" name="email" value="<?php echo e(old('email')); ?>" id="email" class="form-control mt-2" placeholder="Enter email address">
                        <span class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <div class="form-group mb-3">
                        <label for="password">Password</label>
                        <input type="password" name="password" value="<?php echo e(old('password')); ?>" id="password" class="form-control mt-2" placeholder="Enter password">
                        <span class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-success" type="submit">Login</button>
                    </div>
                </form>
                <p class="mt-3" style="font-family: Arial, Helvetica, sans-serif; font-size:14px; color:rgb(139, 133, 133);"><a href="">Forget Your Password</a>!</p>
                <p class="mt-2" style="font-family: Arial, Helvetica, sans-serif; font-size:14px; color:rgb(139, 133, 133);">You don't hava any Account. Please <a href="<?php echo e(route('user.register')); ?>">Register Now</a>!</p>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\projects\ecommerce\resources\views/dashboard/user/login.blade.php ENDPATH**/ ?>