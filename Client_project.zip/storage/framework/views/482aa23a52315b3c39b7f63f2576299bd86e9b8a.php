    <!-- ==========JavaScript Libraries========== -->
        <!-- ======================================== -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="assets/lib/wow/wow.min.js"></script>
        <script src="assets/lib/easing/easing.min.js"></script>
        <script src="assets/lib/waypoints/waypoints.min.js"></script>
        <script src="assets/lib/owlcarousel/owl.carousel.min.js"></script>
        <script src="assets/lib/isotope/isotope.pkgd.min.js"></script>
        <script src="assets/lib/lightbox/js/lightbox.min.js"></script>
        <!-- main Javascript -->
        <script src="assets/js/main.js"></script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\Client_project\resources\views/app/components/footer_script.blade.php ENDPATH**/ ?>