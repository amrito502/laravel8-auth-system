<?php echo $__env->make('app.app_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>













<?php /**PATH C:\xampp\htdocs\Client_project\resources\views/welcome.blade.php ENDPATH**/ ?>