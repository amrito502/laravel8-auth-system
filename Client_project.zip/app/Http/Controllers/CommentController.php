<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Project;
use App\Models\Comment;
use Illuminate\Support\Facades\Response;


class CommentController extends Controller
{
    
}
